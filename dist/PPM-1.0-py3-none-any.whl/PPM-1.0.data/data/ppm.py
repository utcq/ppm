

def main():
    import pmlib.cli as ui
    ui.init()

if __name__ == "__main__": main()
